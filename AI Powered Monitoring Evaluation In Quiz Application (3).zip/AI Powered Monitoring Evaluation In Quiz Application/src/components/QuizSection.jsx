import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { geminiService } from '@/services/geminiService';
import { storageService } from '@/services/storageService';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, Lightbulb, SkipForward, CheckCircle } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const QuizSection = ({ section, onComplete, onScreenshot }) => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [answers, setAnswers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showHint, setShowHint] = useState(false);
  const [hint, setHint] = useState('');
  const [evaluation, setEvaluation] = useState('');
  const [timeLeft, setTimeLeft] = useState(1800); // 30 minutes
  const [quizStarted, setQuizStarted] = useState(false);

  useEffect(() => {
    loadQuestions();
  }, [section]);

  useEffect(() => {
    if (quizStarted && timeLeft > 0 && questions.length > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            handleQuizComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [quizStarted, timeLeft, questions]);

  const loadQuestions = async () => {
    setLoading(true);
    try {
      const generatedQuestions = await geminiService.generateQuestions(section, 10);
      setQuestions(generatedQuestions);
      setQuizStarted(true);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load questions. Using fallback questions.",
        variant: "destructive"
      });
      setQuestions(geminiService.getFallbackQuestions(section));
      setQuizStarted(true);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerSelect = (answer) => {
    setSelectedAnswer(answer);
    setEvaluation('');
    setShowHint(false);
  };

  const handleSubmitAnswer = async () => {
    if (!selectedAnswer) {
      toast({
        title: "Please select an answer",
        description: "Choose an option before submitting.",
        variant: "destructive"
      });
      return;
    }

    const currentQuestion = questions[currentQuestionIndex];
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer;
    
    const aiEvaluation = await geminiService.evaluateAnswer(
      currentQuestion.question,
      selectedAnswer,
      currentQuestion.correctAnswer
    );

    const answerData = {
      questionIndex: currentQuestionIndex,
      question: currentQuestion.question,
      selectedAnswer,
      correctAnswer: currentQuestion.correctAnswer,
      isCorrect,
      evaluation: aiEvaluation
    };

    setAnswers([...answers, answerData]);
    setEvaluation(aiEvaluation);

    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setSelectedAnswer('');
        setEvaluation('');
        setShowHint(false);
      } else {
        handleQuizComplete();
      }
    }, 3000);
  };

  const handleSkipQuestion = () => {
    const answerData = {
      questionIndex: currentQuestionIndex,
      question: questions[currentQuestionIndex].question,
      selectedAnswer: 'SKIPPED',
      correctAnswer: questions[currentQuestionIndex].correctAnswer,
      isCorrect: false,
      evaluation: 'Question was skipped.'
    };

    setAnswers([...answers, answerData]);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer('');
      setEvaluation('');
      setShowHint(false);
    } else {
      handleQuizComplete();
    }
  };

  const handleGetHint = async () => {
    if (showHint || !!evaluation) return; // Also disable hint if evaluation is shown
    
    const currentQuestion = questions[currentQuestionIndex];
    const generatedHint = await geminiService.generateHint(
      currentQuestion.question,
      currentQuestion.options
    );
    
    setHint(generatedHint);
    setShowHint(true);
  };

  const handleQuizComplete = () => {
    if (questions.length === 0) {
      onComplete({
        section,
        questions: 0,
        correctAnswers: 0,
        score: 0,
        answers: [],
        timeSpent: 1800 - timeLeft
      });
      return;
    }

    const correctAnswers = answers.filter(a => a.isCorrect).length;
    const score = Math.round((correctAnswers / questions.length) * 100);
    
    const quizResult = {
      section,
      questions: questions.length,
      correctAnswers,
      score,
      answers,
      timeSpent: 1800 - timeLeft
    };

    const currentUser = storageService.getCurrentUser();
    if (currentUser) {
      storageService.saveQuizResult(currentUser.id, quizResult);
    }

    onComplete(quizResult);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-lg text-white">Generating questions with AI...</p>
        </div>
      </div>
    );
  }

  if (questions.length === 0 && !loading) {
    return (
      <div className="text-center py-8">
        <p className="text-lg text-red-400">Failed to load questions. Please try again.</p>
        <Button onClick={loadQuestions} className="mt-4">
          Retry
        </Button>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white">{section} Quiz</h1>
          <p className="text-gray-300">Question {currentQuestionIndex + 1} of {questions.length}</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-white">
            <Clock className="w-5 h-5" />
            <span className="font-mono text-lg">{formatTime(timeLeft)}</span>
          </div>
          <Badge variant="secondary">
            {Math.round(progress)}% Complete
          </Badge>
        </div>
      </div>

      <div className="w-full bg-gray-700 rounded-full h-2 mb-8">
        <motion.div
          className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>

      <Card className="question-card mb-6">
        <CardHeader>
          <CardTitle className="text-xl text-white">
            {currentQuestion.question}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3">
            {Object.entries(currentQuestion.options).map(([key, value]) => (
              <motion.button
                key={key}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleAnswerSelect(key)}
                className={`p-4 text-left rounded-lg border-2 transition-all ${
                  selectedAnswer === key
                    ? 'border-blue-500 bg-blue-500/20 text-white'
                    : 'border-gray-600 bg-gray-800/50 text-gray-300 hover:border-gray-500'
                }`}
              >
                <span className="font-semibold mr-3">{key}.</span>
                {value}
              </motion.button>
            ))}
          </div>

          <AnimatePresence>
            {showHint && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 p-4 bg-yellow-500/20 border border-yellow-500/30 rounded-lg"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Lightbulb className="w-4 h-4 text-yellow-400" />
                  <span className="font-semibold text-yellow-400">Hint</span>
                </div>
                <p className="text-gray-300">{hint}</p>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {evaluation && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 p-4 bg-green-500/20 border border-green-500/30 rounded-lg"
              >
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="font-semibold text-green-400">AI Evaluation</span>
                </div>
                <p className="text-gray-300">{evaluation}</p>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex gap-3 mt-6">
            <Button
              onClick={handleSubmitAnswer}
              disabled={!selectedAnswer || !!evaluation}
              className="flex-1 quiz-gradient text-white font-semibold"
            >
              Submit Answer
            </Button>
            <Button
              onClick={handleGetHint}
              variant="outline"
              disabled={showHint || !!evaluation}
              className="flex items-center gap-2"
            >
              <Lightbulb className="w-4 h-4" />
              Hint
            </Button>
            <Button
              onClick={handleSkipQuestion}
              variant="outline"
              disabled={!!evaluation}
              className="flex items-center gap-2"
            >
              <SkipForward className="w-4 h-4" />
              Skip
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default QuizSection;