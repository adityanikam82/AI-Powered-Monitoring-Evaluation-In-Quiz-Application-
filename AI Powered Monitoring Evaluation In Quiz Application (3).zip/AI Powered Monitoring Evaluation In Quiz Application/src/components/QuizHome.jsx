import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { storageService } from '@/services/storageService';
import { motion } from 'framer-motion';
import { 
  Code, 
  Database, 
  Monitor, 
  Cloud, 
  Trophy, 
  Clock, 
  User,
  LogOut,
  Brain
} from 'lucide-react';

const QuizHome = ({ user, onStartQuiz, onLogout }) => {
  const [selectedSection, setSelectedSection] = useState(null);

  const quizSections = [
    {
      id: 'C++',
      title: 'C++ Programming',
      description: 'Object-oriented programming, pointers, STL, and advanced concepts',
      icon: Code,
      color: 'from-blue-500 to-cyan-500',
      difficulty: 'Intermediate'
    },
    {
      id: 'Database',
      title: 'Database Systems',
      description: 'SQL, normalization, ACID properties, and database design',
      icon: Database,
      color: 'from-green-500 to-emerald-500',
      difficulty: 'Intermediate'
    },
    {
      id: 'Operating Systems',
      title: 'Operating Systems',
      description: 'Process management, memory, file systems, and scheduling',
      icon: Monitor,
      color: 'from-purple-500 to-violet-500',
      difficulty: 'Advanced'
    },
    {
      id: 'Cloud Computing',
      title: 'Cloud Computing',
      description: 'AWS, Azure, containerization, and cloud architecture',
      icon: Cloud,
      color: 'from-orange-500 to-red-500',
      difficulty: 'Advanced'
    }
  ];

  const getUserStats = () => {
    const userResults = storageService.getQuizResultsByUser(user.id);
    const totalQuizzes = userResults.length;
    const averageScore = totalQuizzes > 0 
      ? Math.round(userResults.reduce((sum, r) => sum + r.score, 0) / totalQuizzes)
      : 0;
    const bestScore = totalQuizzes > 0 
      ? Math.max(...userResults.map(r => r.score))
      : 0;

    return { totalQuizzes, averageScore, bestScore };
  };

  const stats = getUserStats();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-center mb-8"
        >
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">
              AI-Powered Quiz Platform
            </h1>
            <p className="text-gray-300 flex items-center gap-2">
              <Brain className="w-5 h-5" />
              Powered by Gemini AI for intelligent question generation and evaluation
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-white font-semibold">{user.name}</p>
              <p className="text-gray-400 text-sm">{user.email}</p>
            </div>
            <Button
              onClick={onLogout}
              variant="outline"
              className="flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </motion.div>

        {/* User Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Quizzes Taken</p>
                    <p className="text-3xl font-bold">{stats.totalQuizzes}</p>
                  </div>
                  <Trophy className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gradient-to-r from-green-500 to-teal-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Average Score</p>
                    <p className="text-3xl font-bold">{stats.averageScore}%</p>
                  </div>
                  <User className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gradient-to-r from-orange-500 to-red-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Best Score</p>
                    <p className="text-3xl font-bold">{stats.bestScore}%</p>
                  </div>
                  <Trophy className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Quiz Sections */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mb-8"
        >
          <h2 className="text-2xl font-bold text-white mb-6">Choose Your Quiz Section</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {quizSections.map((section, index) => {
              const Icon = section.icon;
              return (
                <motion.div
                  key={section.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Card className="bg-gray-900/50 backdrop-blur-sm border-gray-700 hover:border-gray-600 transition-all cursor-pointer group">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className={`p-3 rounded-lg bg-gradient-to-r ${section.color}`}>
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        <Badge variant="secondary">{section.difficulty}</Badge>
                      </div>
                      <CardTitle className="text-white group-hover:text-blue-300 transition-colors">
                        {section.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-400 mb-4">{section.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Clock className="w-4 h-4" />
                          <span>30 minutes</span>
                        </div>
                        <Button
                          onClick={() => onStartQuiz(section.id)}
                          className={`bg-gradient-to-r ${section.color} text-white font-semibold`}
                        >
                          Start Quiz
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Features */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="bg-gray-900/30 backdrop-blur-sm rounded-lg p-6 border border-gray-700"
        >
          <h3 className="text-xl font-bold text-white mb-4">Platform Features</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <Brain className="w-4 h-4 text-blue-400" />
              </div>
              <div>
                <p className="text-white font-medium">AI-Generated Questions</p>
                <p className="text-gray-400 text-sm">Dynamic questions powered by Gemini AI</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center">
                <Trophy className="w-4 h-4 text-green-400" />
              </div>
              <div>
                <p className="text-white font-medium">Smart Evaluation</p>
                <p className="text-gray-400 text-sm">AI-powered answer assessment</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <Monitor className="w-4 h-4 text-purple-400" />
              </div>
              <div>
                <p className="text-white font-medium">Live Monitoring</p>
                <p className="text-gray-400 text-sm">Camera-based proctoring system</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default QuizHome;