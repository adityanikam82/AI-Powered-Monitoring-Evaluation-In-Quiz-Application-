import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { storageService } from '@/services/storageService';
import { Users, FileText, Camera, TrendingUp, Download } from 'lucide-react';
import { motion } from 'framer-motion';

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [quizResults, setQuizResults] = useState([]);
  const [screenshots, setScreenshots] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setUsers(storageService.getUsers().filter(u => u.role !== 'admin'));
    setQuizResults(storageService.getQuizResults());
    setScreenshots(storageService.getScreenshots());
  };

  const getUserStats = (userId) => {
    const userResults = quizResults.filter(r => r.userId === userId);
    const userScreenshots = screenshots.filter(s => s.userId === userId);
    
    return {
      totalQuizzes: userResults.length,
      averageScore: userResults.length > 0 
        ? Math.round(userResults.reduce((sum, r) => sum + r.score, 0) / userResults.length)
        : 0,
      screenshotCount: userScreenshots.length,
      lastActivity: userResults.length > 0 
        ? new Date(Math.max(...userResults.map(r => new Date(r.completedAt)))).toLocaleDateString()
        : 'Never'
    };
  };

  const downloadUserData = (user) => {
    const userResults = quizResults.filter(r => r.userId === user.id);
    const userScreenshots = screenshots.filter(s => s.userId === user.id);
    
    const data = {
      user,
      quizResults: userResults,
      screenshots: userScreenshots,
      stats: getUserStats(user.id)
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${user.name}_quiz_data.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getOverallStats = () => {
    const totalUsers = users.length;
    const totalQuizzes = quizResults.length;
    const totalScreenshots = screenshots.length;
    const averageScore = quizResults.length > 0
      ? Math.round(quizResults.reduce((sum, r) => sum + r.score, 0) / quizResults.length)
      : 0;

    return { totalUsers, totalQuizzes, totalScreenshots, averageScore };
  };

  const stats = getOverallStats();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">Admin Dashboard</h1>
          <p className="text-gray-300">Monitor quiz activities and user performance</p>
        </motion.div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="admin-gradient text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Total Users</p>
                    <p className="text-3xl font-bold">{stats.totalUsers}</p>
                  </div>
                  <Users className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="quiz-gradient text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Total Quizzes</p>
                    <p className="text-3xl font-bold">{stats.totalQuizzes}</p>
                  </div>
                  <FileText className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gradient-to-r from-green-500 to-teal-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Average Score</p>
                    <p className="text-3xl font-bold">{stats.averageScore}%</p>
                  </div>
                  <TrendingUp className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-gradient-to-r from-orange-500 to-red-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Screenshots</p>
                    <p className="text-3xl font-bold">{stats.totalScreenshots}</p>
                  </div>
                  <Camera className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="results">Quiz Results</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <Card className="bg-gray-900/50 backdrop-blur-sm border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">User Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users.map((user) => {
                    const userStats = getUserStats(user.id);
                    return (
                      <motion.div
                        key={user.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg border border-gray-700"
                      >
                        <div className="flex-1">
                          <h3 className="text-white font-semibold">{user.name}</h3>
                          <p className="text-gray-400 text-sm">{user.email}</p>
                          <div className="flex gap-4 mt-2">
                            <span className="text-xs text-gray-500">
                              Quizzes: {userStats.totalQuizzes}
                            </span>
                            <span className="text-xs text-gray-500">
                              Avg Score: {userStats.averageScore}%
                            </span>
                            <span className="text-xs text-gray-500">
                              Last Active: {userStats.lastActivity}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">
                            {userStats.screenshotCount} photos
                          </Badge>
                          <Button
                            size="sm"
                            onClick={() => downloadUserData(user)}
                            className="flex items-center gap-1"
                          >
                            <Download className="w-4 h-4" />
                            Export
                          </Button>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results">
            <Card className="bg-gray-900/50 backdrop-blur-sm border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Quiz Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {quizResults.map((result) => {
                    const user = users.find(u => u.id === result.userId);
                    return (
                      <motion.div
                        key={result.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-4 bg-gray-800/50 rounded-lg border border-gray-700"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="text-white font-semibold">
                              {user?.name || 'Unknown User'}
                            </h3>
                            <p className="text-gray-400 text-sm">{result.section} Quiz</p>
                          </div>
                          <Badge 
                            variant={result.score >= 70 ? "default" : "destructive"}
                          >
                            {result.score}%
                          </Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm text-gray-400">
                          <span>Questions: {result.questions}</span>
                          <span>Correct: {result.correctAnswers}</span>
                          <span>Time: {Math.floor(result.timeSpent / 60)}m {result.timeSpent % 60}s</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-2">
                          Completed: {new Date(result.completedAt).toLocaleString()}
                        </p>
                      </motion.div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monitoring">
            <Card className="bg-gray-900/50 backdrop-blur-sm border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Screenshot Monitoring</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {screenshots.map((screenshot) => {
                    const user = users.find(u => u.id === screenshot.userId);
                    return (
                      <motion.div
                        key={screenshot.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-gray-800/50 rounded-lg border border-gray-700 overflow-hidden"
                      >
                        <img
                          src={screenshot.screenshot}
                          alt="Quiz screenshot"
                          className="w-full h-32 object-cover"
                        />
                        <div className="p-3">
                          <h4 className="text-white font-medium text-sm">
                            {user?.name || 'Unknown User'}
                          </h4>
                          <p className="text-gray-400 text-xs">
                            {new Date(screenshot.timestamp).toLocaleString()}
                          </p>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;