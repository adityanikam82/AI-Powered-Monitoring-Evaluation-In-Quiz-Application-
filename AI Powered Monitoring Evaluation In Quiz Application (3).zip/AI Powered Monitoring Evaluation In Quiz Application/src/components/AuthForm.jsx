import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { storageService } from '@/services/storageService';
import { motion } from 'framer-motion';
import { User, Mail, Lock, LogIn, UserPlus } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const AuthForm = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (isLogin) {
      // Login logic
      const user = storageService.getUserByEmail(formData.email);
      if (user && user.password === formData.password) {
        storageService.setCurrentUser(user);
        onLogin(user);
        toast({
          title: "Welcome back!",
          description: `Logged in as ${user.name}`,
        });
      } else {
        toast({
          title: "Login failed",
          description: "Invalid email or password",
          variant: "destructive"
        });
      }
    } else {
      // Signup logic
      if (!formData.name || !formData.email || !formData.password) {
        toast({
          title: "Please fill all fields",
          description: "All fields are required for registration",
          variant: "destructive"
        });
        return;
      }

      const existingUser = storageService.getUserByEmail(formData.email);
      if (existingUser) {
        toast({
          title: "Email already exists",
          description: "Please use a different email or login instead",
          variant: "destructive"
        });
        return;
      }

      const newUser = {
        ...formData,
        role: 'student'
      };
      
      storageService.saveUser(newUser);
      storageService.setCurrentUser(newUser);
      onLogin(newUser);
      
      toast({
        title: "Account created!",
        description: `Welcome ${newUser.name}! You can now take quizzes.`,
      });
    }
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="bg-gray-900/80 backdrop-blur-sm border-gray-700">
          <CardHeader className="text-center">
            <motion.div
              initial={{ y: -20 }}
              animate={{ y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <CardTitle className="text-3xl font-bold text-white mb-2">
                {isLogin ? 'Welcome Back' : 'Create Account'}
              </CardTitle>
              <p className="text-gray-400">
                {isLogin 
                  ? 'Sign in to access your quizzes' 
                  : 'Join us to start taking AI-powered quizzes'
                }
              </p>
            </motion.div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      type="text"
                      name="name"
                      placeholder="Full Name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="pl-10 bg-gray-800 border-gray-600 text-white"
                      required={!isLogin}
                    />
                  </div>
                </motion.div>
              )}
              
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  type="email"
                  name="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="pl-10 bg-gray-800 border-gray-600 text-white"
                  required
                />
              </div>
              
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  type="password"
                  name="password"
                  placeholder="Password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="pl-10 bg-gray-800 border-gray-600 text-white"
                  required
                />
              </div>

              <Button
                type="submit"
                className="w-full quiz-gradient text-white font-semibold py-3"
              >
                {isLogin ? (
                  <>
                    <LogIn className="w-4 h-4 mr-2" />
                    Sign In
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4 mr-2" />
                    Create Account
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-gray-400">
                {isLogin ? "Don't have an account?" : "Already have an account?"}
              </p>
              <Button
                variant="link"
                onClick={() => setIsLogin(!isLogin)}
                className="text-blue-400 hover:text-blue-300"
              >
                {isLogin ? 'Sign up here' : 'Sign in here'}
              </Button>
            </div>

            {/* Admin Credentials Info */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="mt-6 p-4 bg-blue-900/30 rounded-lg border border-blue-500/30"
            >
              <h4 className="text-blue-300 font-semibold mb-2">Admin Access</h4>
              <p className="text-xs text-gray-400 mb-2">
                Use these credentials to access the admin dashboard:
              </p>
              <div className="text-xs text-gray-300 space-y-1">
                <p><strong>Email:</strong> admin@quiz.com</p>
                <p><strong>Password:</strong> admin123</p>
              </div>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default AuthForm;