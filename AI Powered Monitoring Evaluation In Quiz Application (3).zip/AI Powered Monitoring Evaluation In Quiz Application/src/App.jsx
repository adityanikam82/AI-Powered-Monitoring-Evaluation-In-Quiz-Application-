import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { storageService } from '@/services/storageService';
import AuthForm from '@/components/AuthForm';
import QuizHome from '@/components/QuizHome';
import QuizSection from '@/components/QuizSection';
import QuizResults from '@/components/QuizResults';
import AdminDashboard from '@/components/AdminDashboard';
import CameraFeed from '@/components/CameraFeed';
import { motion, AnimatePresence } from 'framer-motion';

function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [currentView, setCurrentView] = useState('auth'); // auth, home, quiz, results, admin
  const [currentSection, setCurrentSection] = useState(null);
  const [quizResults, setQuizResults] = useState(null);
  const [cameraActive, setCameraActive] = useState(false);

  useEffect(() => {
    // Check for existing user session
    const user = storageService.getCurrentUser();
    if (user) {
      setCurrentUser(user);
      if (user.role === 'admin') {
        setCurrentView('admin');
      } else {
        setCurrentView('home');
      }
    }
  }, []);

  const handleLogin = (user) => {
    setCurrentUser(user);
    if (user.role === 'admin') {
      setCurrentView('admin');
    } else {
      setCurrentView('home');
    }
  };

  const handleLogout = () => {
    storageService.clearCurrentUser();
    setCurrentUser(null);
    setCurrentView('auth');
    setCameraActive(false);
  };

  const handleStartQuiz = (section) => {
    setCurrentSection(section);
    setCurrentView('quiz');
    setCameraActive(true);
  };

  const handleQuizComplete = (results) => {
    setQuizResults(results);
    setCurrentView('results');
    setCameraActive(false);
  };

  const handleReturnHome = () => {
    setCurrentView('home');
    setCurrentSection(null);
    setQuizResults(null);
    setCameraActive(false);
  };

  const handleRetakeQuiz = () => {
    setCurrentView('quiz');
    setCameraActive(true);
  };

  const handleScreenshot = (screenshotData) => {
    console.log('Screenshot captured:', screenshotData);
  };

  return (
    <div className="min-h-screen">
      <AnimatePresence mode="wait">
        {currentView === 'auth' && (
          <motion.div
            key="auth"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <AuthForm onLogin={handleLogin} />
          </motion.div>
        )}

        {currentView === 'home' && currentUser && (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <QuizHome
              user={currentUser}
              onStartQuiz={handleStartQuiz}
              onLogout={handleLogout}
            />
          </motion.div>
        )}

        {currentView === 'quiz' && currentSection && (
          <motion.div
            key="quiz"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <QuizSection
              section={currentSection}
              onComplete={handleQuizComplete}
              onScreenshot={handleScreenshot}
            />
            <CameraFeed
              isActive={cameraActive}
              userName={currentUser?.name}
              onScreenshot={handleScreenshot}
            />
          </motion.div>
        )}

        {currentView === 'results' && quizResults && (
          <motion.div
            key="results"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <QuizResults
              results={quizResults}
              onReturnHome={handleReturnHome}
              onRetakeQuiz={handleRetakeQuiz}
            />
          </motion.div>
        )}

        {currentView === 'admin' && currentUser?.role === 'admin' && (
          <motion.div
            key="admin"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <AdminDashboard />
            <div className="fixed bottom-4 right-4">
              <button
                onClick={handleLogout}
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium"
              >
                Logout
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Toaster />
    </div>
  );
}

export default App;